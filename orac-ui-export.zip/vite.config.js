import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      "/api": "http://localhost:5050",
      "/documents.html": "http://localhost:5050",
      "/document-data": "http://localhost:5050"
    }
  }
});